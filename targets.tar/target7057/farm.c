/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_135(unsigned *p)
{
    *p = 3635936695U;
}

unsigned addval_286(unsigned x)
{
    return x + 3284633928U;
}

void setval_151(unsigned *p)
{
    *p = 3284633930U;
}

void setval_445(unsigned *p)
{
    *p = 1483856307U;
}

void setval_384(unsigned *p)
{
    *p = 3251079496U;
}

unsigned getval_304()
{
    return 2547958616U;
}

unsigned getval_408()
{
    return 3347663002U;
}

unsigned getval_111()
{
    return 2455290349U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_228(unsigned x)
{
    return x + 2425537161U;
}

unsigned addval_243(unsigned x)
{
    return x + 3767076929U;
}

unsigned getval_142()
{
    return 3374894729U;
}

unsigned getval_444()
{
    return 3286272328U;
}

unsigned addval_104(unsigned x)
{
    return x + 3286272328U;
}

void setval_206(unsigned *p)
{
    *p = 3353381192U;
}

void setval_349(unsigned *p)
{
    *p = 12702089U;
}

void setval_410(unsigned *p)
{
    *p = 3247492745U;
}

unsigned getval_245()
{
    return 3268315440U;
}

unsigned getval_442()
{
    return 3375419785U;
}

unsigned addval_498(unsigned x)
{
    return x + 3531129481U;
}

unsigned getval_251()
{
    return 3281044109U;
}

unsigned getval_209()
{
    return 3281047049U;
}

void setval_421(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_190(unsigned x)
{
    return x + 3223376265U;
}

void setval_478(unsigned *p)
{
    *p = 3221799563U;
}

unsigned getval_335()
{
    return 2429659554U;
}

unsigned getval_239()
{
    return 3223375496U;
}

unsigned addval_176(unsigned x)
{
    return x + 2429454754U;
}

unsigned getval_441()
{
    return 3677405833U;
}

unsigned addval_237(unsigned x)
{
    return x + 3224949129U;
}

void setval_351(unsigned *p)
{
    *p = 3767093594U;
}

unsigned getval_153()
{
    return 3372798361U;
}

unsigned addval_299(unsigned x)
{
    return x + 3532968329U;
}

void setval_171(unsigned *p)
{
    *p = 3281044105U;
}

unsigned addval_336(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_152(unsigned x)
{
    return x + 3676357257U;
}

unsigned getval_346()
{
    return 2429659444U;
}

void setval_215(unsigned *p)
{
    *p = 3251538205U;
}

unsigned addval_429(unsigned x)
{
    return x + 3252717896U;
}

void setval_451(unsigned *p)
{
    *p = 2425406091U;
}

unsigned addval_321(unsigned x)
{
    return x + 3674787465U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
